/* NoNext v1.0 Chromium Browser Extension Script (https://howover.com/nonext-for-youtube)
 * Copyright 2023 Howover Publications */

function nonext() {
  const next = document.querySelector('.ytp-next-button.ytp-button');

  if (!next) {
    setTimeout(nonext, 100);
    return;
  }

  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (next) {
        next.remove();
        console.log('Next button was removed by NoNext for YouTube. Learn more: https://howover.com/nonext-for-youtube');
        observer.disconnect();
      }
    });
  });

  const config = {
    attributes: true
  };

  observer.observe(next, config);
}

nonext();
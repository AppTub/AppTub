/* NoNext v1.0 Chromium Browser Extension Script (https://howover.com/nonext-youtube)
 * Copyright 2023 Howover Publications
 * This is an encrypted source code. If you are interested in purchasing the original source code, please send an email to: contact@howover.com
 */
function nonext() { //set function to check next button.
var next = document.querySelector('.ytp-next-button.ytp-button'); //set next button.
if (!next) //if next button not available.
{
setTimeout(nonext, 100); //set nonext function timeout.
return; //return to function.
}
var observer = new MutationObserver(function(mutations) { //set mutation observer.
mutations.forEach(function(mutation) { //loop through all mutations.
if (next) //if next button found.
{
next.remove(); //remove next button.
console.log('Next button was removed by NoNext for YouTube. Learn more: https://howover.com/nonext-youtube'); //send console message.
observer.disconnect(); //disconnect mutation observer.
}
});
});

var config = { //set observer config.
attributes: true //check next button element attributes.
};

observer.observe(next, config); //begin next button mutation observer.
}

nonext(); //run nonext function.